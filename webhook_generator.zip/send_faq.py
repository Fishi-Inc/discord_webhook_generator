from dataclasses import field
from discord_webhook import DiscordWebhook, DiscordEmbed
import json
import time
from PIL import Image
import requests
from io import BytesIO
from colorama import init, Fore, Style
init(autoreset=True)


with open('./faq/faq.json') as json_file:
    data = json.load(json_file)

with open('./config.json') as json_file:
    config = json.load(json_file)

if 'https://discord.com/api/webhooks' not in config['webhook_url']:
    print(Style.BRIGHT + Fore.RED + 'Webhook URL is valid\n')
    url = input('Enter Webhook URL or Press enter to exit...\n> ')
    if 'https://discord.com/api/webhooks' not in url:
        exit()
    else:
        config['webhook_url'] = url

print('\nSending webhook...')

for x in data:
    webhook = DiscordWebhook(url=config['webhook_url'])
    embed = DiscordEmbed(title=x['title'], description=x['desc'], color='36393F')
    webhook.add_embed(embed)
    webhook.avatar_url = config['webhook_avatar']
    webhook.username = config['webhook_name']
    webhook.execute()
    time.sleep(1)

print(Style.BRIGHT + Fore.GREEN + 'Successfully sent webhook!\n')
input('Press enter to exit...')
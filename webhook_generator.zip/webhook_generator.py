import subprocess
from colorama import init, Fore, Style, Back


init(autoreset=True)

print(''' 
 _       __     __    __                __      ______                                 __            
| |     / /__  / /_  / /_  ____  ____  / /__   / ____/___ ____  ____  ___  _________ _/ /_____  _____
| | /| / / _ \/ __ \/ __ \/ __ \/ __ \/ //_/  / / __/ __ `/ _ \/ __ \/ _ \/ ___/ __ `/ __/ __ \/ ___/
| |/ |/ /  __/ /_/ / / / / /_/ / /_/ / ,<    / /_/ / /_/ /  __/ / / /  __/ /  / /_/ / /_/ /_/ / /    
|__/|__/\___/_.___/_/ /_/\____/\____/_/|_|   \____/\__, /\___/_/ /_/\___/_/   \__,_/\__/\____/_/     
                                                  /____/                                 by Fishi_Inc
''')


print(Back.WHITE + Fore.BLACK + 'Enter what type of webhook you want to send:')
print('''
1 - PLANS
2 - STATUS
3 - FAQ
''')

x = input('> ') 


if (x == '1'):
    subprocess.call('send_plans.py', shell=True)
elif (x == '2'):
    subprocess.call('send_status.py', shell=True)
elif (x == '3'):
    subprocess.call('send_faq.py', shell=True)
